export interface Email {
    enquiryId: number;
    toEmail: string;
    subject: string;
    body: string;
}