export class MasterDataDto {
    id: number;
    name: string;
}

