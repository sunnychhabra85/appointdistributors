export class LocationDto {
    id: number;
    distributorshipTypeId: number;
    name: string;
    parentId: number;
}