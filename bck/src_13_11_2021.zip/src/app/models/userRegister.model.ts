
export class UserRegisterDto {
    name: string;
    mobileNumber: number;
    email: string;
    password: string;
    confirmPassword: string;
}
