export const environment = {
  production: true,
  // API_URL: 'https://dmsapi20210529232937.azurewebsites.net',
  API_URL:'https://api.appointdistributors.com', //"https://apitest.appointdistributors.com" 
};
